"""
Phantom Overlay — v2.0 "Architect Edition"
==========================================
Новые системы:
  [1] Plugin Engine  — папка plugins/, горячая загрузка через importlib
  [2] Web Dashboard  — http://localhost:7777  (REST + HTML UI)
  [3] Auto-Profiles  — папка profiles/, автосмена при старте процессов
"""

import sys, os, json, time, random, threading, asyncio, importlib, importlib.util
import importlib.util as _ilu
import psutil
import keyboard
import pygetwindow as gw
import pyttsx3
from pypresence import Presence
from ping3 import ping
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse

import requests
try:
    import mss, mss.tools
    HAS_MSS = True
except ImportError:
    HAS_MSS = False

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget,
    QSystemTrayIcon, QMenu, QStyle, QDialog, QFormLayout, QSlider,
    QPushButton, QFileDialog, QCheckBox, QHBoxLayout, QLineEdit,
    QTabWidget, QColorDialog, QStackedWidget, QFrame, QScrollArea
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QPoint, QPropertyAnimation,
    QEasingCurve, QRect, QTimer, QSize
)
from PyQt6.QtGui import QAction, QIcon, QPainter, QPen, QColor, QPixmap

try:
    from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as SessionManager
    HAS_WINSDK = True
except ImportError:
    HAS_WINSDK = False

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
CONFIG_FILE = "phantom_config.json"
DEFAULT_CONFIG = {
    "opacity": 180,
    "theme": "dark",
    "bg_image": "",
    "show_ai": True,
    "smart_hide": False,
    "enable_voice": True,
    "show_in_taskbar": False,
    "hotkey_toggle": "ctrl+shift+p",
    "pos_x": 100,
    "pos_y": 100,
    "crosshair_enabled": False,
    "crosshair_color": "#00ff99",
    "crosshair_size": 10,
    "crosshair_thickness": 2,
    "crosshair_gap": 4,
    "screenshot_hotkey": "ctrl+shift+s",
    "tg_token": "",
    # Новые ключи v2
    "web_port": 7777,
    "active_profile": "default",
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return {**DEFAULT_CONFIG, **json.load(f)}
        except: pass
    return DEFAULT_CONFIG.copy()

def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)


# ─────────────────────────────────────────────
# [1] PLUGIN ENGINE
# ─────────────────────────────────────────────
"""
Интерфейс плагина (создайте файл в папке plugins/):

    PLUGIN_META = {
        "name": "MyPlugin",
        "version": "1.0",
        "author": "you",
        "description": "Does something cool",
    }

    class PhantomPlugin:
        def __init__(self, config: dict): ...
        def on_data(self, data: dict) -> dict:
            # data — словарь с cpu/ram/ping/gpu_temp/gpu_util/music/active
            # Возвращай data (можешь добавлять свои ключи)
            return data
        def get_label(self) -> str | None:
            # Строка для отображения в оверлее. None = не показывать
            return None
        def on_config_change(self, config: dict): ...
"""

PLUGINS_DIR = "plugins"

class PluginEngine:
    def __init__(self, config: dict):
        self.config = config
        self.plugins: list = []          # список экземпляров PhantomPlugin
        self.plugin_metas: list = []     # список PLUGIN_META
        os.makedirs(PLUGINS_DIR, exist_ok=True)
        self._load_all()
        self._start_watcher()

    def _load_all(self):
        self.plugins.clear()
        self.plugin_metas.clear()
        for fname in os.listdir(PLUGINS_DIR):
            if fname.endswith(".py") and not fname.startswith("_"):
                self._load_one(os.path.join(PLUGINS_DIR, fname))

    def _load_one(self, path: str):
        try:
            spec = _ilu.spec_from_file_location(
                f"phantom_plugin_{os.path.basename(path)}", path
            )
            mod = _ilu.module_from_spec(spec)
            spec.loader.exec_module(mod)

            meta = getattr(mod, "PLUGIN_META", {"name": os.path.basename(path)})
            cls  = getattr(mod, "PhantomPlugin", None)
            if cls is None:
                return
            instance = cls(self.config)
            self.plugins.append(instance)
            self.plugin_metas.append(meta)
            print(f"[Plugin] Загружен: {meta.get('name')} v{meta.get('version','?')}")
        except Exception as e:
            print(f"[Plugin] Ошибка загрузки {path}: {e}")

    def _start_watcher(self):
        """Следит за папкой plugins/ и перезагружает при изменениях."""
        self._snapshots: dict[str, float] = {}

        def _watch():
            while True:
                try:
                    current = {
                        f: os.path.getmtime(os.path.join(PLUGINS_DIR, f))
                        for f in os.listdir(PLUGINS_DIR)
                        if f.endswith(".py") and not f.startswith("_")
                    }
                    if current != self._snapshots:
                        self._snapshots = current
                        self._load_all()
                        print("[Plugin] Плагины перезагружены")
                except: pass
                time.sleep(3)

        threading.Thread(target=_watch, daemon=True).start()

    def process(self, data: dict) -> dict:
        for plugin in self.plugins:
            try:
                data = plugin.on_data(data) or data
            except Exception as e:
                print(f"[Plugin] on_data ошибка: {e}")
        return data

    def get_labels(self) -> list[str]:
        labels = []
        for plugin in self.plugins:
            try:
                lbl = plugin.get_label()
                if lbl:
                    labels.append(lbl)
            except: pass
        return labels

    def notify_config(self):
        for plugin in self.plugins:
            try: plugin.on_config_change(self.config)
            except: pass

    def list_plugins(self) -> list[dict]:
        return [
            {**m, "active": True}
            for m in self.plugin_metas
        ]


# ─────────────────────────────────────────────
# [2] AUTO-PROFILES
# ─────────────────────────────────────────────
"""
Профиль — JSON-файл в папке profiles/.
Пример profiles/shooter.json:
{
    "name": "Shooter Mode",
    "triggers": ["cs2", "valorant", "overwatch"],   <- подстроки названия процесса
    "config_override": {
        "crosshair_enabled": true,
        "crosshair_color": "#ff3333",
        "opacity": 140,
        "smart_hide": false
    }
}

profiles/default.json — используется когда ничего не совпало.
"""

PROFILES_DIR = "profiles"

class ProfileManager:
    def __init__(self, base_config: dict, on_change=None):
        self.base_config = base_config
        self.on_change = on_change          # callback(merged_config)
        self.active_profile_name = "default"
        os.makedirs(PROFILES_DIR, exist_ok=True)
        self._ensure_default()
        self._start()

    def _ensure_default(self):
        path = os.path.join(PROFILES_DIR, "default.json")
        if not os.path.exists(path):
            default = {
                "name": "Default",
                "triggers": [],
                "config_override": {}
            }
            with open(path, "w", encoding="utf-8") as f:
                json.dump(default, f, indent=4)

    def _load_profiles(self) -> list[dict]:
        profiles = []
        for fname in os.listdir(PROFILES_DIR):
            if fname.endswith(".json"):
                try:
                    with open(os.path.join(PROFILES_DIR, fname), encoding="utf-8") as f:
                        p = json.load(f)
                        p["_file"] = fname
                        profiles.append(p)
                except: pass
        return profiles

    def _start(self):
        def _loop():
            last = None
            while True:
                try:
                    running = {p.name().lower() for p in psutil.process_iter(['name'])}
                    profiles = self._load_profiles()

                    matched = "default"
                    override = {}
                    for profile in profiles:
                        if profile.get("_file") == "default.json":
                            continue
                        triggers = [t.lower() for t in profile.get("triggers", [])]
                        if any(t in proc for proc in running for t in triggers):
                            matched = profile.get("name", profile["_file"])
                            override = profile.get("config_override", {})
                            break

                    if matched != last:
                        last = matched
                        self.active_profile_name = matched
                        merged = {**self.base_config, **override}
                        print(f"[Profile] Активирован: {matched}")
                        if self.on_change:
                            self.on_change(merged)
                except: pass
                time.sleep(5)

        threading.Thread(target=_loop, daemon=True).start()

    def save_profile(self, name: str, triggers: list, override: dict):
        fname = name.lower().replace(" ", "_") + ".json"
        data = {"name": name, "triggers": triggers, "config_override": override}
        with open(os.path.join(PROFILES_DIR, fname), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def list_profiles(self) -> list[dict]:
        return [
            {**p, "active": p.get("name") == self.active_profile_name}
            for p in self._load_profiles()
        ]


# ─────────────────────────────────────────────
# [3] WEB DASHBOARD
# ─────────────────────────────────────────────
_web_state: dict = {}   # глобальный стейт (обновляется из MonitorThread)

WEB_HTML = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Phantom Overlay — Remote</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #0a0a0f; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; }
  header { background: #111118; border-bottom: 1px solid #00ff99; padding: 14px 24px;
            display: flex; align-items: center; gap: 12px; }
  header h1 { color: #00ff99; font-size: 20px; letter-spacing: 2px; text-transform: uppercase; }
  .badge { background: #00ff9922; color: #00ff99; border: 1px solid #00ff9955;
           padding: 3px 10px; border-radius: 20px; font-size: 12px; }
  main { padding: 24px; display: grid; gap: 16px;
         grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); }
  .card { background: #111118; border: 1px solid #1e1e2a; border-radius: 14px; padding: 20px; }
  .card h2 { color: #00ff99; font-size: 13px; text-transform: uppercase;
              letter-spacing: 1px; margin-bottom: 14px; }
  .stat { display: flex; justify-content: space-between; padding: 8px 0;
          border-bottom: 1px solid #1a1a24; font-size: 14px; }
  .stat:last-child { border: none; }
  .val { color: #fff; font-weight: bold; }
  .accent { color: #00ff99; }
  label { display: flex; justify-content: space-between; align-items: center;
          padding: 8px 0; font-size: 13px; cursor: pointer; }
  input[type=range] { width: 140px; accent-color: #00ff99; }
  input[type=text] { background: #1a1a24; border: 1px solid #333; color: #fff;
                     padding: 6px 10px; border-radius: 6px; width: 140px; font-size: 13px; }
  input[type=checkbox] { accent-color: #00ff99; width: 16px; height: 16px; }
  button { background: #00ff9922; color: #00ff99; border: 1px solid #00ff99;
           border-radius: 8px; padding: 8px 16px; cursor: pointer; font-size: 13px;
           transition: background .2s; margin-top: 10px; }
  button:hover { background: #00ff9944; }
  .pill { display: inline-block; background: #1a2a1a; color: #00ff99; border-radius: 20px;
          padding: 2px 10px; font-size: 12px; margin: 2px; }
  #profile-name { color: #ffcc66; font-weight: bold; }
  .plugin-row { display: flex; justify-content: space-between; padding: 6px 0;
                border-bottom: 1px solid #1a1a24; font-size: 13px; }
</style>
</head>
<body>
<header>
  <h1>⬡ PHANTOM</h1>
  <span class="badge" id="status-badge">● ONLINE</span>
  <span style="margin-left:auto;font-size:12px;color:#555;" id="last-update">—</span>
</header>
<main>
  <!-- Мониторинг -->
  <div class="card">
    <h2>📊 Система</h2>
    <div class="stat"><span>CPU</span><span class="val accent" id="s-cpu">—</span></div>
    <div class="stat"><span>RAM</span><span class="val" id="s-ram">—</span></div>
    <div class="stat"><span>GPU Temp</span><span class="val" id="s-gpu-t">—</span></div>
    <div class="stat"><span>GPU Load</span><span class="val" id="s-gpu-u">—</span></div>
    <div class="stat"><span>Ping</span><span class="val accent" id="s-ping">—</span></div>
    <div class="stat"><span>Окно</span><span class="val" id="s-win" style="font-size:11px;max-width:160px;overflow:hidden;text-overflow:ellipsis;">—</span></div>
    <div class="stat"><span>Музыка</span><span class="val" id="s-music" style="font-size:11px;">—</span></div>
  </div>

  <!-- Настройки -->
  <div class="card">
    <h2>⚙ Настройки</h2>
    <label>Прозрачность
      <input type="range" id="cfg-opacity" min="20" max="255"
             oninput="patchCfg('opacity', parseInt(this.value))">
    </label>
    <label>Прицел
      <input type="checkbox" id="cfg-crosshair"
             onchange="patchCfg('crosshair_enabled', this.checked)">
    </label>
    <label>Цвет прицела
      <input type="color" id="cfg-color"
             oninput="patchCfg('crosshair_color', this.value)">
    </label>
    <label>Smart Hide
      <input type="checkbox" id="cfg-smart"
             onchange="patchCfg('smart_hide', this.checked)">
    </label>
    <label>Голос
      <input type="checkbox" id="cfg-voice"
             onchange="patchCfg('enable_voice', this.checked)">
    </label>
  </div>

  <!-- Профиль -->
  <div class="card">
    <h2>🎭 Auto-Profile</h2>
    <div class="stat"><span>Активный</span><span id="profile-name">—</span></div>
    <div id="profile-list" style="margin-top:10px;"></div>
  </div>

  <!-- Плагины -->
  <div class="card">
    <h2>🔌 Плагины</h2>
    <div id="plugin-list"><span style="color:#555;font-size:12px;">Нет загруженных плагинов</span></div>
  </div>
</main>
<script>
let cfg = {};
async function refresh() {
  try {
    const r = await fetch('/api/state'); const d = await r.json();
    document.getElementById('s-cpu').textContent   = d.cpu + '%';
    document.getElementById('s-ram').textContent   = d.ram + '%';
    document.getElementById('s-gpu-t').textContent = d.gpu_temp + '°C';
    document.getElementById('s-gpu-u').textContent = d.gpu_util + '%';
    document.getElementById('s-ping').textContent  = d.ping + ' ms';
    document.getElementById('s-win').textContent   = (d.active||'').slice(0,28);
    document.getElementById('s-music').textContent = (d.music||'').slice(0,28);
    document.getElementById('last-update').textContent = new Date().toLocaleTimeString();

    cfg = d.config || {};
    document.getElementById('cfg-opacity').value   = cfg.opacity || 180;
    document.getElementById('cfg-crosshair').checked = !!cfg.crosshair_enabled;
    document.getElementById('cfg-color').value     = cfg.crosshair_color || '#00ff99';
    document.getElementById('cfg-smart').checked   = !!cfg.smart_hide;
    document.getElementById('cfg-voice').checked   = !!cfg.enable_voice;

    document.getElementById('profile-name').textContent = d.active_profile || 'default';
    const pl = d.profiles || [];
    document.getElementById('profile-list').innerHTML = pl.map(p =>
      `<div class="plugin-row"><span>${p.name||p._file}</span>
       <span class="pill">${(p.triggers||[]).join(', ')||'всегда'}</span></div>`
    ).join('');

    const plugins = d.plugins || [];
    document.getElementById('plugin-list').innerHTML = plugins.length
      ? plugins.map(p => `<div class="plugin-row"><span>${p.name}</span>
          <span class="pill">v${p.version||'?'}</span></div>`).join('')
      : '<span style="color:#555;font-size:12px;">Нет загруженных плагинов</span>';
  } catch(e) {}
}
async function patchCfg(key, value) {
  cfg[key] = value;
  await fetch('/api/config', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({[key]: value})});
}
setInterval(refresh, 1500);
refresh();
</script>
</body>
</html>
"""

class _WebHandler(BaseHTTPRequestHandler):
    """Минимальный HTTP-обработчик без внешних зависимостей."""

    overlay_ref = None   # будет установлен при старте

    def log_message(self, *a): pass  # заглушаем стандартный лог

    def _send(self, code, ctype, body):
        if isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self._send(200, "text/html; charset=utf-8", WEB_HTML)

        elif self.path == "/api/state":
            overlay = _WebHandler.overlay_ref
            state = dict(_web_state)
            if overlay:
                state["config"] = overlay.config
                state["active_profile"] = overlay.profile_mgr.active_profile_name
                state["profiles"] = overlay.profile_mgr.list_profiles()
                state["plugins"] = overlay.plugin_engine.list_plugins()
            self._send(200, "application/json", json.dumps(state, ensure_ascii=False))

        else:
            self._send(404, "text/plain", "Not Found")

    def do_POST(self):
        if self.path == "/api/config":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                patch = json.loads(body)
                overlay = _WebHandler.overlay_ref
                if overlay:
                    overlay.config.update(patch)
                    save_config(overlay.config)
                    overlay.plugin_engine.notify_config()
                self._send(200, "application/json", '{"ok":true}')
            except Exception as e:
                self._send(400, "application/json", f'{{"error":"{e}"}}')
        else:
            self._send(404, "text/plain", "Not Found")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

def start_web_server(port: int, overlay):
    _WebHandler.overlay_ref = overlay
    server = HTTPServer(("0.0.0.0", port), _WebHandler)

    def _run():
        print(f"[Web] Dashboard → http://localhost:{port}")
        server.serve_forever()

    threading.Thread(target=_run, daemon=True).start()


# ─────────────────────────────────────────────
# PHANTOM CORE (голос + Discord RPC)
# ─────────────────────────────────────────────
class PhantomCore:
    def __init__(self):
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', 180)
        self.last_speech_time = 0
        self.rpc = None
        self.discord_connected = False

    def init_discord(self):
        try:
            self.rpc = Presence("121456789012345678")
            self.rpc.connect()
            self.discord_connected = True
        except: self.discord_connected = False

    def update_discord(self, state, details):
        if self.discord_connected and self.rpc:
            try: self.rpc.update(state=state, details=details, large_image="logo")
            except: pass

    def say(self, text):
        if time.time() - self.last_speech_time < 10: return
        self.last_speech_time = time.time()
        def _speak():
            try: self.engine.say(text); self.engine.runAndWait()
            except: pass
        threading.Thread(target=_speak, daemon=True).start()


# ─────────────────────────────────────────────
# CROSSHAIR
# ─────────────────────────────────────────────
class CrosshairOverlay(QWidget):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setGeometry(QApplication.primaryScreen().geometry())

    def paintEvent(self, event):
        if not self.config.get("crosshair_enabled", False): return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor(self.config.get("crosshair_color", "#00ff99"))
        pen = QPen(color, self.config.get("crosshair_thickness", 2))
        painter.setPen(pen)
        cx, cy = self.width() // 2, self.height() // 2
        s = self.config.get("crosshair_size", 10)
        g = self.config.get("crosshair_gap", 4)
        painter.drawLine(cx-s-g, cy, cx-g, cy)
        painter.drawLine(cx+g, cy, cx+s+g, cy)
        painter.drawLine(cx, cy-s-g, cx, cy-g)
        painter.drawLine(cx, cy+g, cx, cy+s+g)

    def update_config(self, config):
        self.config = config
        self.setVisible(self.config.get("crosshair_enabled", False))
        self.update()


# ─────────────────────────────────────────────
# MONITOR THREAD
# ─────────────────────────────────────────────
class MonitorThread(QThread):
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.loop = asyncio.new_event_loop()
        self.nvml_initialized = False
        try:
            import pynvml
            pynvml.nvmlInit()
            self.gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            self.nvml_initialized = True
            self.pynvml = pynvml
        except: pass

    def run(self):
        asyncio.set_event_loop(self.loop)
        while True:
            try:
                data = {"cpu": psutil.cpu_percent(), "ram": psutil.virtual_memory().percent}
                if self.nvml_initialized:
                    data["gpu_temp"] = self.pynvml.nvmlDeviceGetTemperature(
                        self.gpu_handle, self.pynvml.NVML_TEMPERATURE_GPU)
                    data["gpu_util"] = self.pynvml.nvmlDeviceGetUtilizationRates(self.gpu_handle).gpu
                else:
                    data["gpu_temp"] = data["gpu_util"] = 0

                p = ping("8.8.8.8", timeout=0.5)
                data["ping"] = int(p * 1000) if p else "Loss"

                win = gw.getActiveWindow()
                data["active"] = win.title if win else ""
                data["music"] = self.loop.run_until_complete(self.get_music())

                _web_state.update(data)   # → web dashboard
                self.updated.emit(data)
            except: pass
            time.sleep(1)

    async def get_music(self):
        if not HAS_WINSDK: return ""
        try:
            sessions = await SessionManager.request_async()
            curr = sessions.get_current_session()
            if curr:
                info = await curr.try_get_media_properties_async()
                return f"{info.artist} - {info.title}"
        except: pass
        return ""


# ─────────────────────────────────────────────
# SETTINGS DIALOG
# ─────────────────────────────────────────────
class PremiumSettings(QDialog):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.parent_overlay = parent
        self.setFixedSize(650, 520)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.init_ui()
        self.apply_styles()

    def init_ui(self):
        self.main_frame = QFrame(self)
        self.main_frame.setObjectName("mainFrame")
        self.main_frame.setGeometry(0, 0, 650, 520)

        layout = QHBoxLayout(self.main_frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.sidebar = QFrame()
        self.sidebar.setFixedWidth(80)
        self.sidebar.setObjectName("sidebar")
        side_layout = QVBoxLayout(self.sidebar)
        side_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        for icon, idx in [("nav_gen.png",0),("nav_des.png",1),("nav_aim.png",2),("nav_mod.png",3)]:
            side_layout.addWidget(self.create_nav_btn(icon, idx))
        side_layout.addStretch()
        btn_close = QPushButton("✕")
        btn_close.setFixedSize(40, 40)
        btn_close.clicked.connect(self.close)
        side_layout.addWidget(btn_close, alignment=Qt.AlignmentFlag.AlignCenter)

        self.stack = QStackedWidget()

        # Страница 1: Общие
        p1 = QWidget(); l1 = QFormLayout(p1); l1.setContentsMargins(30, 30, 30, 30)
        self.hk_main = QLineEdit(self.config["hotkey_toggle"])
        self.hk_main.textChanged.connect(lambda t: self.upd_cfg("hotkey_toggle", t))
        self.cb_smart = QCheckBox("Smart Focus (Авто-скрытие)")
        self.cb_smart.setChecked(self.config["smart_hide"])
        self.cb_smart.stateChanged.connect(lambda s: self.upd_cfg("smart_hide", bool(s)))
        self.cb_voice = QCheckBox("Голос Силфиетты")
        self.cb_voice.setChecked(self.config["enable_voice"])
        self.cb_voice.stateChanged.connect(lambda s: self.upd_cfg("enable_voice", bool(s)))
        port_lbl = QLabel(f"Web dashboard: http://localhost:{self.config.get('web_port',7777)}")
        port_lbl.setStyleSheet("color:#00ff99;font-size:11px;")
        l1.addRow("Хоткей оверлея:", self.hk_main)
        l1.addRow("Умное скрытие:", self.cb_smart)
        l1.addRow("Звуковые оповещения:", self.cb_voice)
        l1.addRow("", port_lbl)
        self.stack.addWidget(p1)

        # Страница 2: Дизайн
        p2 = QWidget(); l2 = QFormLayout(p2); l2.setContentsMargins(30, 30, 30, 30)
        self.sl_op = QSlider(Qt.Orientation.Horizontal)
        self.sl_op.setRange(20, 255)
        self.sl_op.setValue(self.config["opacity"])
        self.sl_op.valueChanged.connect(self.upd_op)
        self.btn_bg = QPushButton("🖼 Выбрать фон")
        self.btn_bg.clicked.connect(self.set_bg)
        l2.addRow("Прозрачность:", self.sl_op)
        l2.addRow("Обои:", self.btn_bg)
        self.stack.addWidget(p2)

        # Страница 3: Прицел
        p3 = QWidget(); l3 = QFormLayout(p3); l3.setContentsMargins(30, 30, 30, 30)
        self.cb_aim = QCheckBox("Включить прицел")
        self.cb_aim.setChecked(self.config["crosshair_enabled"])
        self.cb_aim.stateChanged.connect(lambda s: self.upd_cfg("crosshair_enabled", bool(s)))
        self.sl_size = QSlider(Qt.Orientation.Horizontal)
        self.sl_size.setRange(2, 50)
        self.sl_size.setValue(self.config["crosshair_size"])
        self.sl_size.valueChanged.connect(lambda v: self.upd_cfg("crosshair_size", v))
        self.sl_thick = QSlider(Qt.Orientation.Horizontal)
        self.sl_thick.setRange(1, 10)
        self.sl_thick.setValue(self.config["crosshair_thickness"])
        self.sl_thick.valueChanged.connect(lambda v: self.upd_cfg("crosshair_thickness", v))
        self.btn_col = QPushButton("Выбрать цвет")
        self.btn_col.clicked.connect(self.set_color)
        l3.addRow("Статус:", self.cb_aim)
        l3.addRow("Размер:", self.sl_size)
        l3.addRow("Толщина:", self.sl_thick)
        l3.addRow("Цвет:", self.btn_col)
        self.stack.addWidget(p3)

        # Страница 4: Модули / Плагины
        p4 = QWidget(); l4 = QVBoxLayout(p4); l4.setContentsMargins(30, 30, 30, 30)
        info = QLabel("Плагины загружаются из папки <b>plugins/</b><br>"
                      "Профили — из папки <b>profiles/</b><br><br>"
                      "Создай .py файл в plugins/ — он подхватится автоматически.")
        info.setWordWrap(True)
        info.setStyleSheet("color:#a8b2d1;font-size:12px;")

        self.hk_ss = QLineEdit(self.config["screenshot_hotkey"])
        self.hk_ss.textChanged.connect(lambda t: self.upd_cfg("screenshot_hotkey", t))
        lbl_ss = QLabel("Хоткей скриншота:")
        lbl_ss.setStyleSheet("color:#a8b2d1;font-weight:bold;")

        l4.addWidget(info)
        l4.addSpacing(10)
        l4.addWidget(lbl_ss)
        l4.addWidget(self.hk_ss)
        self.stack.addWidget(p4)

        layout.addWidget(self.sidebar)
        layout.addWidget(self.stack)

    def create_nav_btn(self, icon, index):
        b = QPushButton()
        b.setFixedSize(60, 60)
        if os.path.exists(icon):
            b.setIcon(QIcon(icon)); b.setIconSize(QSize(30, 30))
        else:
            b.setText(str(index))
        b.clicked.connect(lambda: self.stack.setCurrentIndex(index))
        return b

    def upd_cfg(self, k, v):
        self.config[k] = v
        save_config(self.config)
        self.parent_overlay.register_hotkeys()
        self.parent_overlay.crosshair.update_config(self.config)
        self.parent_overlay.plugin_engine.notify_config()

    def upd_op(self, v):
        self.config["opacity"] = v
        self.parent_overlay.apply_config()

    def set_color(self):
        c = QColorDialog.getColor(QColor(self.config["crosshair_color"]))
        if c.isValid(): self.upd_cfg("crosshair_color", c.name())

    def set_bg(self):
        f, _ = QFileDialog.getOpenFileName(self, "Выбор фона", "", "Images (*.png *.jpg *.jpeg)")
        if f:
            self.config["bg_image"] = f
            save_config(self.config)
            self.parent_overlay.apply_config()

    def apply_styles(self):
        self.setStyleSheet("""
            #mainFrame { background-color: rgba(18,18,24,250); border: 2px solid #00ff99; border-radius: 20px; }
            #sidebar { background-color: rgba(10,10,15,255); border-top-left-radius: 20px; border-bottom-left-radius: 20px; }
            QPushButton { background: transparent; border: none; color: #00ff99; font-weight: bold; border-radius: 10px; font-size: 14px; }
            QPushButton:hover { background: rgba(0,255,153,30); }
            QLineEdit { background: #1a1a24; border: 1px solid #333; color: white; padding: 8px; border-radius: 5px; }
            QCheckBox { color: white; font-size: 13px; }
            QLabel { color: #a8b2d1; font-weight: bold; font-size: 13px; }
            QSlider::groove:horizontal { background: #333; height: 4px; border-radius: 2px; }
            QSlider::handle:horizontal { background: #00ff99; width: 14px; margin: -5px 0; border-radius: 7px; }
        """)


# ─────────────────────────────────────────────
# MAIN OVERLAY
# ─────────────────────────────────────────────
class PhantomOverlay(QMainWindow):
    toggle_sig = pyqtSignal()
    ss_sig = pyqtSignal()
    profile_sig = pyqtSignal(dict)   # для смены профиля из фонового потока

    def __init__(self):
        super().__init__()
        self.config = load_config()
        self.core = PhantomCore()
        self.crosshair = CrosshairOverlay(self.config)
        self.is_locked = True

        # --- Системы v2 ---
        self.plugin_engine = PluginEngine(self.config)
        self.profile_mgr = ProfileManager(self.config, on_change=self._on_profile_change)

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self.cont = QWidget(); self.setCentralWidget(self.cont)
        self.lay = QVBoxLayout(self.cont)
        self.lay.setContentsMargins(15, 12, 15, 12)

        self.lbl_gpu   = QLabel("GPU: --°C")
        self.lbl_cpu   = QLabel("CPU: --%")
        self.lbl_music = QLabel("")
        self.lbl_ping  = QLabel("PING: -- ms")
        self.lbl_ai    = QLabel("🤖 Silphiette: Ready")
        self.lbl_plugin = QLabel("")  # строка от плагинов

        style = "color: white; font-family: 'Segoe UI'; font-weight: bold; font-size: 13px;"
        for lbl in [self.lbl_gpu, self.lbl_cpu, self.lbl_ping]:
            lbl.setStyleSheet(style); self.lay.addWidget(lbl)

        self.lbl_music.setStyleSheet("color: #a8b2d1; font-size: 11px;")
        self.lbl_ai.setStyleSheet("color: #ffcc66; font-style: italic; font-size: 11px;")
        self.lbl_plugin.setStyleSheet("color: #aaaaff; font-size: 11px;")

        self.lay.addWidget(self.lbl_music)
        self.lay.addWidget(self.lbl_ai)
        self.lay.addWidget(self.lbl_plugin)

        self.apply_config()
        self.register_hotkeys()
        self.setup_tray()
        self.core.init_discord()

        self.mon = MonitorThread()
        self.mon.updated.connect(self.update_ui)
        self.mon.start()

        self.toggle_sig.connect(lambda: self.setVisible(not self.isVisible()))
        self.ss_sig.connect(self.capture_ss)
        self.profile_sig.connect(self._apply_profile)

        # Запуск веб-сервера
        start_web_server(self.config.get("web_port", 7777), self)

    def _on_profile_change(self, merged_config: dict):
        """Вызывается из фонового потока ProfileManager — пробрасываем в Qt через сигнал."""
        self.profile_sig.emit(merged_config)

    def _apply_profile(self, merged_config: dict):
        self.config.update(merged_config)
        self.apply_config()
        self.crosshair.update_config(self.config)
        self.plugin_engine.notify_config()
        profile = self.profile_mgr.active_profile_name
        self.lbl_ai.setText(f"🎭 Профиль: {profile}")

    def register_hotkeys(self):
        keyboard.unhook_all()
        try:
            keyboard.add_hotkey(self.config["hotkey_toggle"], self.toggle_sig.emit)
            keyboard.add_hotkey(self.config["screenshot_hotkey"], self.ss_sig.emit)
        except: pass

    def capture_ss(self):
        if not HAS_MSS: return
        self.hide(); self.crosshair.hide()
        QTimer.singleShot(200, self._do_ss)

    def _do_ss(self):
        os.makedirs("Screenshots", exist_ok=True)
        with mss.mss() as sct:
            sct.shot(output=f"Screenshots/PH_{int(time.time())}.png")
        self.core.say("Снимок экрана сохранен")
        self.show()
        if self.config["crosshair_enabled"]: self.crosshair.show()

    def apply_config(self):
        self.setWindowOpacity(self.config["opacity"] / 255.0)
        self.move(self.config["pos_x"], self.config["pos_y"])

        bg = self.config["bg_image"].replace("\\", "/")
        bg_style = (
            f"border-image: url('{bg}') 0 0 0 0 stretch stretch;"
            if bg and os.path.exists(bg)
            else "background: rgba(15,15,20,230);"
        )
        border = "2px solid #00ff99" if not self.is_locked else "1px solid #333"
        self.cont.setStyleSheet(f"{bg_style} border: {border}; border-radius: 15px;")
        self.lbl_ai.setVisible(self.config["show_ai"])

    def setup_tray(self):
        self.tray = QSystemTrayIcon(self)
        ico = QIcon("icon.png") if os.path.exists("icon.png") else self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
        self.tray.setIcon(ico)
        m = QMenu()
        m.addAction("🛠 Двигать", self.toggle_lock)
        m.addAction("⚙ Настройки", lambda: PremiumSettings(self.config, self).show())
        m.addAction("🌐 Открыть Dashboard", lambda: os.startfile(f"http://localhost:{self.config.get('web_port',7777)}"))
        m.addAction("❌ Выход", sys.exit)
        self.tray.setContextMenu(m)
        self.tray.show()

    def toggle_lock(self):
        self.is_locked = not self.is_locked
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, self.is_locked)
        self.apply_config()

    def update_ui(self, data: dict):
        # Прогоняем через плагины
        data = self.plugin_engine.process(data)

        gpu_t = data.get("gpu_temp", 0)
        self.lbl_gpu.setText(f"GPU: {gpu_t}°C | {data.get('gpu_util',0)}%")
        self.lbl_cpu.setText(f"CPU: {data['cpu']}% | RAM: {data['ram']}%")
        self.lbl_ping.setText(f"PING: {data['ping']} ms")

        music = data.get("music", "")
        self.lbl_music.setText(music[:30] + "…" if len(music) > 30 else music)

        # Строки от плагинов
        plugin_labels = self.plugin_engine.get_labels()
        self.lbl_plugin.setText(" | ".join(plugin_labels) if plugin_labels else "")
        self.lbl_plugin.setVisible(bool(plugin_labels))

        if gpu_t > 82 and self.config["enable_voice"]:
            self.core.say("Внимание, видеокарта перегревается!")

        self.core.update_discord(f"GPU: {gpu_t}°C", music[:30])

        if self.config["smart_hide"] and self.is_locked:
            games = ["cs2", "genshin", "dota", "minecraft", "gta", "cyberpunk"]
            is_game = any(g in data["active"].lower() for g in games)
            self.setVisible(is_game)
            if self.config["crosshair_enabled"]:
                self.crosshair.setVisible(is_game)

    def mousePressEvent(self, e):
        if not self.is_locked and e.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if not self.is_locked and e.buttons() == Qt.MouseButton.LeftButton and hasattr(self, "_drag_pos"):
            new_pos = e.globalPosition().toPoint() - self._drag_pos
            self.move(new_pos)
            self.config["pos_x"] = new_pos.x()
            self.config["pos_y"] = new_pos.y()
            save_config(self.config)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    overlay = PhantomOverlay()
    overlay.show()
    sys.exit(app.exec())
